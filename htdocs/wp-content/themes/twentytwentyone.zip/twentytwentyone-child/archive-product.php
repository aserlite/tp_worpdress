<?php

global $post;

$args = array(
    'posts_per_page'   => 16,
    'orderby'          => 'rand',
    'post_type'        => 'product' );

$products = get_posts( $args );

foreach ( $products as $post ) : setup_postdata( $post ); ?>
    <div class="product">
        <a href="<?php the_permalink(); ?>">
            <?php the_title(); ?></a>
    </div>
<?php endforeach;
wp_reset_postdata();
?>